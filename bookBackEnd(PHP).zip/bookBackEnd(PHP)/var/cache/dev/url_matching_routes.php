<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/api/get-by-properties/books' => [[['_route' => 'getBooks', '_controller' => 'App\\Controller\\GetBookByPropertiesAction', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\Book', '_api_operation_name' => 'getBooks'], null, ['GET' => 0], null, false, false, null]],
        '/api/get-by-properties/categories' => [[['_route' => 'getCategory', '_controller' => 'App\\Controller\\GetCategoryByPropertiesAction', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\Category', '_api_operation_name' => 'getCategory'], null, ['GET' => 0], null, false, false, null]],
        '/api/get-by-properties/users' => [[['_route' => 'getUsers', '_controller' => 'App\\Controller\\GetUserByPropertiesAction', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\User', '_api_operation_name' => 'getUsers'], null, ['GET' => 0], null, false, false, null]],
        '/api/max-age/users' => [[['_route' => 'maxAge', '_controller' => 'App\\Controller\\UserGetMaxAgeAction', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\User', '_api_operation_name' => 'maxAge'], null, ['GET' => 0], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/api(?'
                    .'|/\\.well\\-known/genid/([^/]++)(*:43)'
                    .'|(?:/(index)(?:\\.([^/]++))?)?(*:78)'
                    .'|/(?'
                        .'|docs(?:\\.([^/]++))?(*:108)'
                        .'|c(?'
                            .'|ontexts/([^.]+)(?:\\.(jsonld))?(*:150)'
                            .'|ategories(?'
                                .'|/([^/\\.]++)(?:\\.([^/]++))?(*:196)'
                                .'|(?:\\.([^/]++))?(*:219)'
                                .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                    .'|(*:256)'
                                .')'
                                .'|(?:\\.([^/]++))?(*:280)'
                            .')'
                        .')'
                        .'|books(?'
                            .'|(?:\\.([^/]++))?(*:313)'
                            .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                .'|(*:350)'
                            .')'
                            .'|(?:\\.([^/]++))?(*:374)'
                        .')'
                        .'|media_objects(?'
                            .'|/([^/\\.]++)(?:\\.([^/]++))?(*:425)'
                            .'|(?:\\.([^/]++))?(?'
                                .'|(*:451)'
                            .')'
                        .')'
                        .'|users(?'
                            .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                .'|(*:498)'
                            .')'
                            .'|(?:\\.([^/]++))?(*:522)'
                            .'|/(?'
                                .'|full\\-name(*:544)'
                                .'|auth(*:556)'
                            .')'
                        .')'
                    .')'
                .')'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:596)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        43 => [[['_route' => 'api_genid', '_controller' => 'api_platform.action.not_exposed', '_api_respond' => 'true'], ['id'], null, null, false, true, null]],
        78 => [[['_route' => 'api_entrypoint', '_controller' => 'api_platform.action.entrypoint', '_format' => '', '_api_respond' => 'true', 'index' => 'index'], ['index', '_format'], null, null, false, true, null]],
        108 => [[['_route' => 'api_doc', '_controller' => 'api_platform.action.documentation', '_format' => '', '_api_respond' => 'true'], ['_format'], null, null, false, true, null]],
        150 => [[['_route' => 'api_jsonld_context', '_controller' => 'api_platform.jsonld.action.context', '_format' => 'jsonld', '_api_respond' => 'true'], ['shortName', '_format'], null, null, false, true, null]],
        196 => [[['_route' => '_api_/categories/{id}.{_format}_delete', '_controller' => 'api_platform.action.placeholder', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\Category', '_api_operation_name' => '_api_/categories/{id}.{_format}_delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null]],
        219 => [[['_route' => '_api_/categories.{_format}_get_collection', '_controller' => 'api_platform.action.placeholder', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\Category', '_api_operation_name' => '_api_/categories.{_format}_get_collection'], ['_format'], ['GET' => 0], null, false, true, null]],
        256 => [
            [['_route' => '_api_/categories/{id}.{_format}_put', '_controller' => 'api_platform.action.placeholder', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\Category', '_api_operation_name' => '_api_/categories/{id}.{_format}_put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => '_api_/categories/{id}.{_format}_get', '_controller' => 'api_platform.action.placeholder', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\Category', '_api_operation_name' => '_api_/categories/{id}.{_format}_get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
        ],
        280 => [[['_route' => '_api_/categories.{_format}_post', '_controller' => 'api_platform.action.placeholder', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\Category', '_api_operation_name' => '_api_/categories.{_format}_post'], ['_format'], ['POST' => 0], null, false, true, null]],
        313 => [[['_route' => '_api_/books.{_format}_get_collection', '_controller' => 'api_platform.action.placeholder', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\Book', '_api_operation_name' => '_api_/books.{_format}_get_collection'], ['_format'], ['GET' => 0], null, false, true, null]],
        350 => [
            [['_route' => '_api_/books/{id}.{_format}_put', '_controller' => 'api_platform.action.placeholder', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\Book', '_api_operation_name' => '_api_/books/{id}.{_format}_put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => '_api_/books/{id}.{_format}_get', '_controller' => 'api_platform.action.placeholder', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\Book', '_api_operation_name' => '_api_/books/{id}.{_format}_get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => '_api_/books/{id}.{_format}_delete', '_controller' => 'api_platform.action.placeholder', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\Book', '_api_operation_name' => '_api_/books/{id}.{_format}_delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
        ],
        374 => [[['_route' => '_api_/books.{_format}_post', '_controller' => 'api_platform.action.placeholder', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\Book', '_api_operation_name' => '_api_/books.{_format}_post'], ['_format'], ['POST' => 0], null, false, true, null]],
        425 => [[['_route' => '_api_/media_objects/{id}.{_format}_get', '_controller' => 'api_platform.action.placeholder', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\MediaObject', '_api_operation_name' => '_api_/media_objects/{id}.{_format}_get'], ['id', '_format'], ['GET' => 0], null, false, true, null]],
        451 => [
            [['_route' => '_api_/media_objects.{_format}_get_collection', '_controller' => 'api_platform.action.placeholder', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\MediaObject', '_api_operation_name' => '_api_/media_objects.{_format}_get_collection'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => '_api_/media_objects.{_format}_post', '_controller' => 'App\\Controller\\CreateMediaObjectAction', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\MediaObject', '_api_operation_name' => '_api_/media_objects.{_format}_post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        498 => [
            [['_route' => '_api_/users/{id}.{_format}_delete', '_controller' => 'api_platform.action.placeholder', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\User', '_api_operation_name' => '_api_/users/{id}.{_format}_delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => '_api_/users/{id}.{_format}_get', '_controller' => 'api_platform.action.placeholder', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\User', '_api_operation_name' => '_api_/users/{id}.{_format}_get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
        ],
        522 => [[['_route' => 'createUser', '_controller' => 'App\\Controller\\UserCreateAction', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\User', '_api_operation_name' => 'createUser'], ['_format'], ['POST' => 0], null, false, true, null]],
        544 => [[['_route' => 'fullName', '_controller' => 'App\\Controller\\UserFullNameAction', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\User', '_api_operation_name' => 'fullName'], [], ['POST' => 0], null, false, false, null]],
        556 => [[['_route' => 'auth', '_controller' => 'api_platform.action.placeholder', '_format' => null, '_stateless' => null, '_api_resource_class' => 'App\\Entity\\User', '_api_operation_name' => 'auth'], [], ['POST' => 0], null, false, false, null]],
        596 => [
            [['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
