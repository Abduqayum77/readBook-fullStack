import axios from "axios";

export default {
    actions: {
        fetchToken(context, data) {
            return new Promise((resolve, reject) => {
                axios.post('http://localhost:8080/api/users/auth', data)
                    .then((response) => {
                        console.log('Token olindi')
                        console.log(response)

                        context.commit('updateToken', response.data.token)
                        resolve()
                    })
                    .catch(() => {
                        console.log('Token olishda xatolik')
                        reject()
                    })
            })
        }
    },
    mutations: {
        updateToken(state, token) {
            localStorage.setItem('token', token)
            state.token = token
        }
    },
    state: {
        token: localStorage.getItem('token'),
    },
    getters: {
        getToken(state) {
            return state.token
        },
        getAuthorize(state) {
            return state.token !== null
        }
    },
}
