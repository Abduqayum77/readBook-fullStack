<template>
    <button
        @click="action"
        type="button"
        class="btn"
        :class="{'btn-success' : btnSuccess, 'btn-primary' : btnPrimary, 'w-100' : width50, 'mt-4' : marginTop4}">
        <span v-if="isLoading" class="spinner-border spinner-border-sm" role="status"></span>
        <span v-else>{{ text }}</span>
    </button>
</template>

<script>
export default {
    name: "ButtonTag",
    props: {
        text: {
            type: String,
            required: true
        },
        isLoading: {
            type: Boolean,
            default: false
        },
        action: {
            type: Function,
            required: true
        },
        btnPrimary: {
            type: Boolean
        },
        btnSuccess: {
            type: Boolean
        },
        width50: {
            type: Boolean
        },
        marginTop4: {
            type: Boolean
        }
    }
}
</script>

<style scoped>

</style>