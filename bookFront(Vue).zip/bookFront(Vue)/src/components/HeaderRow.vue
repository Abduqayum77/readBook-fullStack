<template>

    <div class="row mb-4">
        <div class="col px-0">
            <nav class="navbar navbar-expand-md navbar-dark bg-dark">
                <div class="container-fluid">
                    <router-link class="navbar-brand" to="/">{{ $t('home') }}</router-link>
                    <button
                        class="navbar-toggler"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent"
                        aria-controls="navbarSupportedContent"
                        aria-expanded="false"
                        aria-label="Toggle navigation"
                    >
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                            <li class="nav-item">
                                <router-link class="nav-link" to="/create-book">{{ $t('addBook') }}</router-link>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                   data-bs-toggle="dropdown" aria-expanded="false">
                                    {{ $t('category') }}
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <li>
                                        <router-link class="dropdown-item" to="/create-category">{{
                                                $t('createCategory')
                                            }}
                                        </router-link>
                                    </li>
                                    <li>
                                        <router-link class="dropdown-item" to="/edit-category">{{
                                                $t('changeCategory')
                                            }}
                                        </router-link>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item">
                                <span @click="logOut" class="nav-link" target="_blank">{{ $t('logOut') }}</span>
                            </li>
                        </ul>
                        <form class="d-flex">
                            <select @click="changeLang"
                                    v-model="lang" class="form-select me-3" aria-label="Default select example">
                                <option value="uz">Uzb</option>
                                <option value="ru">Rus</option>
                                <option value="en">Eng</option>
                            </select>
                            <input
                                class="form-control me-2"
                                type="search"
                                placeholder="Search"
                                aria-label="Search"
                            />
                            <button
                                id="searchBtn"
                                class="btn btn-outline-success"
                                type="button"
                            >
                                {{ $t('search') }}
                            </button>
                        </form>
                    </div>
                </div>
            </nav>
        </div>
    </div>

</template>

<script>

export default {
    name: "HeaderRow",
    data() {
        return {
            lang: ''
        }
    },
    methods: {
        logOut() {
            localStorage.removeItem('token')
            location.reload()
        },
        changeLang() {
            this.$i18n.locale = this.lang
        }
    }

}
</script>

<style scoped>
.flag {
    border-radius: 8px;
    border: solid #5cb30b;
    margin-bottom: 0;
    margin-left: 50px;
}

.flag .dropdown-menu {
    text-align: right;
    border: solid #5cb30b;
    border-radius: 8px;
    padding-right: 50%;
    min-width: 4em;
    padding-right: 11px;
    margin-left: 45%;
}

.england-flag {
    width: 2em;
    margin-right: 6%;
}

.russian-flag {
    width: 2.2em;
}

.uzbek-flag {
    width: 1.9em;
    margin: 2% 6% 0 0;
}
</style>