<template>
    <div class="row">
        <div class="col px-0">
            <footer class="p-5 bg-dark text-light text-center">
                &copy;The {{groupName}} group. {{year}}
            </footer>
        </div>
    </div>
</template>

<script>
export default {
    name: "FooterRow",
    props: {
        groupName: {
            type: String,
            required: true
        },
        year: {
            type: Number,
            default: 1800
        }
    }
}
</script>

<style scoped>
</style>