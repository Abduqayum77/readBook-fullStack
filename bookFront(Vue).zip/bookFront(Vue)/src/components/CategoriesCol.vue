<template>
    <div class="col-12 col-sm-5 col-md-4 col-lg-3 ps-2 bg-light">
        <div class="list-group">
            <router-link
                v-for="category in getCategories"
                :key="category.id"
                :to="'/categories/' + category.id"
                class="list-group-item list-group-items-action"
            >
                {{ category.name }}
            </router-link>
        </div>
    </div>
</template>

<script>
import {mapActions, mapGetters} from "vuex";

export default {
    name: "CategoriesCol",
    methods: {
        ...mapActions(['fetchCategories'])
    },
    computed: {
        ...mapGetters(['getCategories'])
    },
    mounted() {
        this.fetchCategories()
    }
}

</script>

<style scoped>

</style>






<!--            <a-->
<!--                href="#"-->
<!--                class="list-group-item list-group-item-action active"-->
<!--                aria-current="true"-->
<!--            >-->
<!--                Self-Improvement-->
<!--            </a>-->
<!--            <a href="#" class="list-group-item list-group-item-action"-->
<!--            >Detective</a-->
<!--            >-->
<!--            <a href="#" class="list-group-item list-group-item-action"-->
<!--            >Classic</a-->
<!--            >-->
<!--            <a href="#" class="list-group-item list-group-item-action"-->
<!--            >Biography</a-->
<!--            >-->
<!--            <a href="#" class="list-group-item list-group-item-action">Comic</a>-->