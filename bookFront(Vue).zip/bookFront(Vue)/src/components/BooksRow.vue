<template>
    <div class="row">
        <div
            v-for="book in getBooks"
            :key="book.id"
            class="col-12 col-md-6 col-lg-4 col-xl-3 mb-4"
        >
            <div class="card">
                <img
                    id="image-resize"
                    :src="'http://localhost:8080' + book.picture.contentUrl"
                    class="card-img-top"
                    alt="..."
                />
                <div class="card-body">
                    <h5 id="text-resize" class="card-title">{{ book.name }}</h5>
                    <p id="text-resize" class="card-text">{{book.description}}</p>
                    <router-link
                        :to="'/book-info/' + book.id"
                        class="btn btn-primary"
                    >O'qish
                    </router-link>

                </div>
            </div>
        </div>
    </div>
</template>

<script>
import {mapActions, mapGetters} from "vuex";

export default {
    name: "BooksRow",
    computed: {
        ...mapGetters(['getBooks'])
    },
    methods: {
        ...mapActions(['fetchBooks'])
    },
    mounted() {
        this.fetchBooks()
    },
    watch: {
        '$route.params.id' () {
            this.fetchBooks('?category=' + this.$route.params.id)
        }
    }
}
</script>

<style scoped>
#image-resize {
    height: 17em;
    width: 100%;
}

#text-resize {
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
}
</style>