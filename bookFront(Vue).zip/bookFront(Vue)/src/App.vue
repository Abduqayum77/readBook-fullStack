<script setup>


import EntryLayout from "@/layout/EntryLayout.vue";
import DefaultLayout from "@/layout/DefaultLayout.vue";

// export default {
//     name: 'App',
//     components: {DefaultLayout, EntryLayout},
// }


</script>

<template>

    <component :is="$route.meta.layout === undefined ? DefaultLayout : EntryLayout"/>

    <!--    <component :is="$route.meta.layout === undefined ? 'DefaultLayout' : $route.meta.layout"/>-->

</template>


<style>


</style>
