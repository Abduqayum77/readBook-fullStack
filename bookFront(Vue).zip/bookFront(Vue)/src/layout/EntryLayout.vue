<template>
    <div class="container-fluid">
        <router-view/>
    </div>
</template>

<script>
export default {
    name: "EntryLayout"
}
</script>

<style scoped>

</style>