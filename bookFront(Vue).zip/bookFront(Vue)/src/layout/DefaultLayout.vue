<template>
    <!-- Container boshlandi-->
    <div class="container-fluid">
        <HeaderRow/>
        <div class="row">
            <CategoriesCol/>

            <router-view/>
        </div>
        <FooterRow group-name="JW-22-07" :year="2022"/>
    </div>
    <!-- Container tugadi-->
</template>

<script>
import HeaderRow from "@/components/HeaderRow.vue";
import CategoriesCol from "@/components/CategoriesCol.vue";
import FooterRow from "@/components/FooterRow.vue";

export default {
    name: "DefaultLayout",
    components: {FooterRow, CategoriesCol, HeaderRow}
}
</script>

<style scoped>

</style>