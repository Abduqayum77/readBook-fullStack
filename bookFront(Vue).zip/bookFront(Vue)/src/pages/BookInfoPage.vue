<template>
    <div class="col-12 col-md-8 col-lg-9 book-info" style="min-height: 500px">
        <h1> {{getBook.name}} </h1>
        <p> {{getBook.text}} </p>
    </div>
</template>

<script>
import {mapActions, mapGetters} from "vuex";

export default {
    name: "BookInfoPage",
    computed: {
        ...mapGetters(['getBook'])
    },
    methods: {
        ...mapActions(['fetchBook'])
    },
    mounted() {
        this.fetchBook(this.$route.params.foo)
    }
}
</script>

<style scoped>
.book-info {
    margin-bottom: 12.7%;
}
</style>