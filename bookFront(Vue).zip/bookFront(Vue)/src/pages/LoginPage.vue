<template>
    <div class="row ">
        <div class="body">
            <div class="login-box">
                <div class="row my-3 mb-5">
                    <div class="col-6">
                        <div :class="isLogin ? 'btn-info' : 'btn-outline-success'" @click="isLogin = true"
                             class="kirish btn btn-outline-success w-100">Kirish
                        </div>
                    </div>
                    <div class="col-6 foo">
                        <div :class="isLogin === false ? 'btn-info' : 'btn-outline-primary'"
                             @click="isLogin = false" class="btn btn-outline-primary w-100">Ro'yxatdan o'tish
                        </div>
                    </div>
                </div>
                <form v-if="isLogin">
                    <div class="user-box">
                        <input v-model="authorization.email" type="email" name="" required="" id="kirishEmail"/>
                        <label for="kirishEmail">Email</label>
                    </div>
                    <div class="user-box">
                        <input v-model="authorization.password" type="text" name="" required="" id="kirishParol"/>
                        <label for="kirishParol">Parol</label>
                    </div>
                    <button @click="signIn" href="#" type="button" id="">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                        Kirish
                    </button>
                </form>
                <form v-else @submit.prevent="signUp">
                    <div class="user-box">
                        <input v-model="registration.email" type="email" name="" required="" id="regEmail"/>
                        <label for="regEmail">Email</label>
                    </div>
                    <div class="user-box">
                        <input v-model="registration.age" type="number" name="" required="" id="regAge"/>
                        <label for="regAge">Yosh</label>
                    </div>
                    <div class="user-box">
                        <input v-model="registration.password" type="text" name="" required="" id="regParol"/>
                        <label for="regParol">Parol</label>
                    </div>
                    <div class="user-box">
                        <input v-model="registration.confirmPassword" type="text" name="" required="" id="regParol2"/>
                        <label for="regParol2">Parolni tasdiqlash</label>
                        <small v-if="isValid" class="text-danger">Parollar mos kelmadi</small>
                    </div>
                    <button href="#" type="submit" id="">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                        Ro'yxatdan o'tish
                    </button>
                </form>
            </div>
        </div>
    </div>
</template>

<script>
import {mapActions} from "vuex";

export default {
    name: "LoginPage",
    data() {
        return {
            isLogin: true,
            isValid: false,
            registration: {
                email: '',
                age: '',
                password: '',
                confirmPassword: '',
            },
            authorization: {
                email: '',
                password: '',
            }
        }
    },
    methods: {
        ...mapActions(['createUser', 'fetchToken']),
        signUp() {
            this.isValid = false

            let data = {
                email: this.registration.email,
                password: this.registration.password,
                age: this.registration.age
            }

            if (this.registration.password === this.registration.confirmPassword) {
                this.createUser(data)
                    .then(() => {
                        this.fetchToken({email: this.registration.email, password: this.registration.password})
                            .then(() => {
                                this.$router.push('/')
                            })
                    })
            } else {
                console.log('User yaratishda xatolik yuz berdi')
                this.isValid = true

            }
        },
        signIn() {
            this.fetchToken(this.authorization)
                .then(() => {
                    //Token olingach bo'sh sahifaga o'tamiz.
                    this.$router.push('/')
                })
            // Bu yerda xam .catch() ishlatishimiz mumkin edi
            // lekin u bizga kerak emas.
        }
    }
}

</script>

<style scoped>

html {
    height: 100%;
}

.body {
    margin: 0;
    padding: 0;
    font-family: sans-serif;
    background: linear-gradient(#141e30, #243b55);
    width: 200%;
    height: 110%;

    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}

.login-box {
    position: absolute;
    top: 50%;
    left: 50%;
    width: 450px;
    padding: 40px;
    transform: translate(-50%, -50%);
    background: rgba(0, 0, 0, 0.5);
    box-sizing: border-box;
    box-shadow: 0 15px 25px rgba(0, 0, 0, 0.6);
    border-radius: 10px;
    margin-top: 3%;
}

.login-box h3 {
    margin: 0 0 30px;
    padding: 0;
    color: #fff;
    text-align: center;
    border: solid #03e9f4;
    width: 100%;
    justify-content: center;
    display: flex;
}

.login-box .user-box {
    position: relative;
}

.login-box .user-box input {
    width: 100%;
    padding: 10px 0;
    font-size: 16px;
    color: #fff;
    margin-bottom: 30px;
    border: none;
    border-bottom: 1px solid #fff;
    outline: none;
    background: transparent;
}

.login-box .user-box label {
    position: absolute;
    top: 0;
    left: 0;
    padding: 10px 0;
    font-size: 16px;
    color: #fff;
    pointer-events: none;
    transition: 0.5s;
}

.login-box .user-box input:focus ~ label,
.login-box .user-box input:valid ~ label {
    top: -20px;
    left: 0;
    color: #03e9f4;
    font-size: 12px;
}

.login-box form button {
    position: relative;
    display: inline-block;
    padding: 10px 20px;
    color: #03e9f4;
    font-size: 14px;
    text-decoration: none;
    text-transform: uppercase;
    overflow: hidden;
    transition: 0.5s;
    margin-top: 40px;
    letter-spacing: 4px;
    border: none;
    background: linear-gradient(#141e30, #243b55);
}

.login-box button:hover {
    background: #03e9f4;
    color: #fff;
    border-radius: 5px;
    box-shadow: 0 0 5px #03e9f4, 0 0 25px #03e9f4, 0 0 50px #03e9f4,
    0 0 100px #03e9f4;
}

.login-box button span {
    position: absolute;
    display: block;
}

.login-box button span:nth-child(1) {
    top: 0;
    left: -100%;
    width: 100%;
    height: 2px;
    background: linear-gradient(90deg, transparent, #03e9f4);
    animation: btn-anim1 1s linear infinite;
}

@keyframes btn-anim1 {
    0% {
        left: -100%;
    }
    50%,
    100% {
        left: 100%;
    }
}

.login-box button span:nth-child(2) {
    top: -100%;
    right: 0;
    width: 2px;
    height: 100%;
    background: linear-gradient(180deg, transparent, #03e9f4);
    animation: btn-anim2 1s linear infinite;
    animation-delay: 0.25s;
}

@keyframes btn-anim2 {
    0% {
        top: -100%;
    }
    50%,
    100% {
        top: 100%;
    }
}

.login-box button span:nth-child(3) {
    bottom: 0;
    right: -100%;
    width: 100%;
    height: 2px;
    background: linear-gradient(270deg, transparent, #03e9f4);
    animation: btn-anim3 1s linear infinite;
    animation-delay: 0.5s;
}

@keyframes btn-anim3 {
    0% {
        right: -100%;
    }
    50%,
    100% {
        right: 100%;
    }
}

.login-box button span:nth-child(4) {
    bottom: -100%;
    left: 0;
    width: 2px;
    height: 100%;
    background: linear-gradient(360deg, transparent, #03e9f4);
    animation: btn-anim4 1s linear infinite;
    animation-delay: 0.75s;
}

@keyframes btn-anim4 {
    0% {
        bottom: -100%;
    }
    50%,
    100% {
        bottom: 100%;
    }
}

</style>