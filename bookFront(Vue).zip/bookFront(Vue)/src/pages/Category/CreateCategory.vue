<template>
    <div class="col-12 col-md-8 col-xl-9" style="min-height:600px">
        <div class="row">
            <div class="col-12 col-md-6 col-xl-4 mb-3">
                <label for="kategoriyaOlish" class="form-label">Kategoriya nomi</label>
                <input v-model="name" type="email" class="form-control" id="kategoriyaOlish"/>

                <ButtonTag
                    :action="create"
                    text="Kategoriya yaratish"
                    btn-success
                    margin-top4
                />
            </div>
        </div>
    </div>
</template>

<script>
import {mapActions} from "vuex";
import ButtonTag from "@/components/tags/ButtonTag.vue";

export default {
    name: "CreateCategory",
    components: {ButtonTag},
    data() {
        return {
            name: '',
        }
    },
    methods: {
        ...mapActions(['createCategory', "fetchCategories"]),
        create() {
            this.createCategory({name: this.name})
                .then(() => {
                    this.fetchCategories()
                })
        }
    }
}
</script>

<style scoped>

</style>