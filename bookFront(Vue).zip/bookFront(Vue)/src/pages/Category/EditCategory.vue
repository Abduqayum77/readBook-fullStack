<template>
    <div class="col-12 col-md-8 col-xl-9" style="min-height:600px">

        <!-- isChange o'zgaruvchani true bo'lsa - kategoriyani o'zgartirish bo'limi ko'rinadi -->
        <div v-if="isChange" class="row">
            <div class="col-12 col-md-6 col-xl-4 mb-3">
                <label for="kategoriyaO'zgartirish" class="form-label">Kategoriya nomi</label>
                <input v-model="name" type="text" class="form-control" id="kategoriyaO'zgartirish"/>

                <button @click="change" type="button" class="mt-4 btn btn-success">Kategoriyani o'zgartirish</button>
            </div>
        </div>

        <!--  isChange qiymati false bo'lsa table ichidagi ma'lumotlar ko'rinadi  -->
        <table v-else class="table">
            <thead>
            <tr>
                <th scope="col">Id</th>
                <th scope="col">Nomi</th>
                <th scope="col">O'zgartirish</th>
                <th scope="col">O'chirish</th>
            </tr>
            </thead>
            <tbody>
                <!--Bekend'dan kelgan kategoriyalarni for orqali joylashtiryabmiz-->
                <tr
                    v-for="category in getCategories"
                    :key="category.id"
                >
                    <td>{{ category.id }}</td>
                    <td>{{ category.name }}</td>
                    <td>
                        <!--
                        Change text'i ustiga bosilgach:
                        - data'dagi isChange qiymatini true'ga tenglayabmiz, shu orqali table
                        yopilib kategoriyani o'zgartirish bo'limi ochiladi.
                        - data'dagi categoryId qiymatini bekend'dan kelgan kategoriya id'siga tengladik.
                        Kategoriya nomi kiritilib change funksiyasi ishlaganda - bekend'ga argument
                        sifatida shu id'ni yuboramiz.
                        -->
                        <span @click="isChange = true; categoryId = category.id" class="table-item">Change</span>
                    </td>
                    <td>
                        <!--
                        Delete text'i ustiga bosilgach:
                        - methods'dagi remove chaqirib, unga argument
                        sifatida - kategoriya id'sini beryabmiz.
                        -->
                        <span @click="remove(category.id)" class="table-item2">Delete</span>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</template>

<script>
import {mapActions, mapGetters} from "vuex";

export default {
    name: "EditCategory",
    data() {
        return {
            name: '',
            isChange: false,
            categoryId: null,
        }
    },
    methods: {
        // Bekend'dan:
        //     - kategoriyalar'ni olish uchun - fetchCategories
        //     - kategoriya'ni o'chirish uchun - deleteCategory
        //     - kategoriya'ni o'zgartirish uchun - putCategory
        // action'larni sahifaga import qildik.
        ...mapActions(['fetchCategories', 'deleteCategory', 'putCategory']),
        remove(id) {
            this.deleteCategory(id)
                .then(() => {
                    // Kategoriya o'chirilgach:
                    //      - fetchCategories() funksiyasini chaqirdik va bekend'dan
                    //      kategoriyalar ro'yxatini qayta oldik. Shu orqali yuqorida
                    //      import qilgan getter'imiz - getCategories'dagi ma'lumotlar yangilanadi
                    this.fetchCategories()
                })
        },
        change() {
            // putCategory'ga qrgument sifatida:
            //      - url'ga qo'shib yuborilgan - id'ni
            //      - body qismida yuboriladigan - name o'zgaruvchanini kiritdik.
            this.putCategory({id: this.categoryId, name: this.name})
                .then(() => {
                    // reload() funksiyasidan sahifani obnovit qilishda foydalandik.
                    location.reload()
                })
        }
    },
    computed: {
        // plugins/models.category/getCategories.js faylida yaratgan getter'imizni
        // sahifaga import qildik. Unda bekend'dan olgan kategoriya'larimiz bor.
        ...mapGetters(['getCategories'])
    }
}
</script>

<style scoped>
.table-item {
    cursor: pointer;
    color: green;
}
.table-item2 {
    cursor: pointer;
    color: red;
}
</style>