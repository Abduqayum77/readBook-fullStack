<template>
    <div class="col-12 col-sm-7 col-md-8 col-lg-9 bg-light">
        <BooksRow/>
        <PaginationRow/>
    </div>
</template>

<script>
import PaginationRow from "@/components/PaginationRow.vue";
import BooksRow from "@/components/BooksRow.vue";

export default {
    name: "HomePage",
    components: {BooksRow, PaginationRow}
}
</script>

<style scoped>

</style>