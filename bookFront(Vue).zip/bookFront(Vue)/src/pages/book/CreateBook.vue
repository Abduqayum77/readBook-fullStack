<template>
    <div class="col-12 col-md-4 col-xl-5" style="min-height:600px">
        <h3>Kitob qo'shish</h3>
        <input v-model="book.name" type="text" class="form-control mb-3" placeholder="name"/>
        <input v-model="book.description" type="text" class="form-control mb-3" placeholder="description"/>
        <textarea v-model="book.text" class="form-control mb-3" rows="3" placeholder="text"/>

        <select v-model="book.category" class="form-select mb-3" aria-label="Default select example">
            <option
                v-for="category in getCategories"
                :key="category.id"
                :value="category['@id']"
            >
             {{category.name}}
            </option>
        </select>

        <input
            @change="selectImage($event)"
            class="form-control mb-3"
            type="file"
        >

        <ButtonTag
            :action="create"
            text="Kitob yaratish"
            width50
            btn-primary
            :is-loading="isLoading"
        />
    </div>
    <div class="col-12 col-md-4 col-xl-4">
        <img v-if="selectedImage !== null" :src="selectedImage" alt="" style="max-width: 200px">
    </div>

</template>

<script>
import {mapActions, mapGetters} from "vuex";
import ButtonTag from "@/components/tags/ButtonTag.vue";

export default {
    name: "CreateBook",
    components: {ButtonTag},
    data() {
        return {
            isLoading: false,
            selectedImage: null,
            imageFile: null,
            book: {
                name: '',
                description: '',
                text: '',
                category: '',
                picture: '',
            }
        }
    },
    computed: {
        ...mapGetters(['getCategories', 'getCreatedFile'])
    },
    methods: {
        ...mapActions(['fetchCategories', 'pushMediaObject', 'createBook']),
        selectImage(event) {
            let data = event.target.files

            if (data.length > 0) {
                this.imageFile = data[0]
                this.selectedImage = URL.createObjectURL(data[0])
            }
        },
        create() {
            this.isLoading = true

            this.pushMediaObject(this.imageFile)
                .then(() => {
                console.log('Tanlangan rasm bazaga joylandi')

                this.book.picture = this.getCreatedFile['@id']

                this.createBook(this.book)
                    .then(() => {
                        location.href = '/'
                    })
            })
                .finally(() => {
                    this.isLoading = false
                })
        }
    },
    mounted() {
        this.fetchCategories()
    }
}
</script>

<style scoped>

</style>